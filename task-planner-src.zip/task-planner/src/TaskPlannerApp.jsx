import { useState, useMemo } from 'react';
import './styles/theme.css';
import Sidebar from './components/Sidebar';
import EditTaskModal from './components/EditTaskModal';
import HomePage from './pages/HomePage';
import CalendarPage from './pages/CalendarPage';
import UpcomingPage from './pages/UpcomingPage';
import SettingsPage from './pages/SettingsPage';
import { PRIORITIES } from './constants/priorities';
import { startOfDay } from './utils/dateUtils';
import { buildSeedTasks } from './utils/seedData';

export default function TaskPlannerApp() {
  const [theme, setTheme] = useState('light');
  const [page, setPage] = useState('home');
  const [tasks, setTasks] = useState(buildSeedTasks);
  const [selectedDate, setSelectedDate] = useState(() => startOfDay(new Date()));
  const [editingTask, setEditingTask] = useState(null);
  const [notifyDefault, setNotifyDefault] = useState(true);
  const [leadMinutes, setLeadMinutes] = useState(15);
  const [profileName, setProfileName] = useState('ผู้ใช้งาน');

  const priorityMap = useMemo(() => Object.fromEntries(PRIORITIES.map((p) => [p.id, p])), []);

  const addTask = (data) =>
    setTasks((prev) => [...prev, { id: `t-${Date.now()}-${Math.random().toString(36).slice(2)}`, done: false, ...data }]);
  const toggleDone = (id) => setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  const deleteTask = (id) => setTasks((prev) => prev.filter((t) => t.id !== id));
  const saveEdit = (updated) => {
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
    setEditingTask(null);
  };

  return (
    <div className="tp-app" data-theme={theme}>
      <Sidebar page={page} setPage={setPage} />
      <main className="tp-main">
        {page === 'home' && (
          <HomePage
            theme={theme} setTheme={setTheme}
            selectedDate={selectedDate} setSelectedDate={setSelectedDate}
            tasks={tasks} priorityMap={priorityMap}
            onAddTask={addTask} onToggle={toggleDone} onEdit={setEditingTask} onDelete={deleteTask}
            notifyDefault={notifyDefault} leadMinutes={leadMinutes}
          />
        )}
        {page === 'calendar' && (
          <CalendarPage
            theme={theme} setTheme={setTheme}
            tasks={tasks} priorityMap={priorityMap}
            selectedDate={selectedDate} setSelectedDate={setSelectedDate} setPage={setPage}
            onToggle={toggleDone} onEdit={setEditingTask} onDelete={deleteTask}
          />
        )}
        {page === 'upcoming' && (
          <UpcomingPage
            theme={theme} setTheme={setTheme}
            tasks={tasks} priorityMap={priorityMap}
            onToggle={toggleDone} onEdit={setEditingTask} onDelete={deleteTask}
          />
        )}
        {page === 'settings' && (
          <SettingsPage
            theme={theme} setTheme={setTheme}
            notifyDefault={notifyDefault} setNotifyDefault={setNotifyDefault}
            leadMinutes={leadMinutes} setLeadMinutes={setLeadMinutes}
            profileName={profileName} setProfileName={setProfileName}
          />
        )}
      </main>
      {editingTask && <EditTaskModal task={editingTask} onClose={() => setEditingTask(null)} onSave={saveEdit} />}
    </div>
  );
}
