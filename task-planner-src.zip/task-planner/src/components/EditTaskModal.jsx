import { useState } from 'react';
import { X } from 'lucide-react';
import TimeReel from './TimeReel';
import PriorityPicker from './PriorityPicker';
import RepeatPicker from './RepeatPicker';
import ToggleSwitch from './ToggleSwitch';

export default function EditTaskModal({ task, onClose, onSave }) {
  const [title, setTitle] = useState(task.title);
  const [hour, setHour] = useState(task.hour);
  const [minute, setMinute] = useState(task.minute);
  const [priority, setPriority] = useState(task.priority);
  const [repeat, setRepeat] = useState(task.repeat);
  const [notify, setNotify] = useState(task.notify);
  const [dateStr, setDateStr] = useState(task.dateKey);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    onSave({ ...task, title: title.trim(), hour, minute, priority, repeat, notify, dateKey: dateStr });
  };

  return (
    <div className="tp-modal-backdrop" onClick={onClose}>
      <div className="tp-modal" onClick={(e) => e.stopPropagation()}>
        <div className="tp-modal-head">
          <h3>แก้ไขงาน</h3>
          <button type="button" className="tp-icon-btn" onClick={onClose} aria-label="ปิดหน้าต่าง"><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit} className="tp-modal-body">
          <label className="tp-field-label">วันที่</label>
          <input type="date" className="tp-date-input" value={dateStr} onChange={(e) => setDateStr(e.target.value)} />

          <label className="tp-field-label">เวลา</label>
          <div className="tp-reel-row">
            <TimeReel value={hour} max={23} onChange={setHour} />
            <span className="tp-reel-colon">:</span>
            <TimeReel value={minute} max={59} onChange={setMinute} />
          </div>

          <label className="tp-field-label">ชื่องาน</label>
          <input className="tp-text-input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="เพิ่มงานใหม่" />

          <label className="tp-field-label">ระดับความสำคัญ</label>
          <PriorityPicker value={priority} onChange={setPriority} />

          <label className="tp-field-label">การทำซ้ำ</label>
          <RepeatPicker value={repeat} onChange={setRepeat} />

          <ToggleSwitch checked={notify} onChange={setNotify} label="แจ้งเตือนก่อนถึงเวลา" description={notify ? 'เปิดอยู่' : 'ปิดอยู่'} />

          <div className="tp-modal-actions">
            <button type="button" className="tp-btn tp-btn-ghost" onClick={onClose}>ยกเลิก</button>
            <button type="submit" className="tp-btn tp-btn-primary">บันทึกการแก้ไข</button>
          </div>
        </form>
      </div>
    </div>
  );
}
