import { useState, useRef } from 'react';
import { Check, Pencil, Trash2 } from 'lucide-react';
import { pad2 } from '../utils/dateUtils';

/** A task row that can be swiped/dragged left to reveal edit and delete buttons. */
export default function TaskItem({ task, priority, onToggle, onEdit, onDelete }) {
  const ACTION_W = 136;
  const [x, setX] = useState(0);
  const [open, setOpen] = useState(false);
  const [dragging, setDragging] = useState(false);
  const drag = useRef({ startX: 0, base: 0 });

  const clamp = (v) => Math.min(0, Math.max(-ACTION_W, v));

  const onPointerDown = (e) => {
    drag.current = { startX: e.clientX, base: x };
    setDragging(true);
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };
  const onPointerMove = (e) => {
    if (!dragging) return;
    setX(clamp(drag.current.base + (e.clientX - drag.current.startX)));
  };
  const endDrag = () => {
    if (!dragging) return;
    setDragging(false);
    const shouldOpen = x < -ACTION_W / 2;
    setOpen(shouldOpen);
    setX(shouldOpen ? -ACTION_W : 0);
  };

  return (
    <div className="tp-task-item">
      <div className="tp-task-actions" style={{ width: ACTION_W }}>
        <button
          type="button"
          className="tp-task-action tp-task-action-edit"
          onClick={() => { onEdit(task); setOpen(false); setX(0); }}
          aria-label="แก้ไขงาน"
        >
          <Pencil size={18} />
        </button>
        <button type="button" className="tp-task-action tp-task-action-delete" onClick={() => onDelete(task.id)} aria-label="ลบงาน">
          <Trash2 size={18} />
        </button>
      </div>
      <div
        className={`tp-task-card ${task.done ? 'is-done' : ''} ${dragging ? '' : 'tp-transition'}`}
        style={{ transform: `translateX(${x}px)` }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerLeave={endDrag}
      >
        <button type="button" className="tp-task-check" onClick={() => onToggle(task.id)} aria-label="ทำเสร็จแล้ว">
          {task.done && <Check size={13} />}
        </button>
        <span className="tp-task-dot" style={{ background: priority.color }} />
        <div className="tp-task-body">
          <span className="tp-task-title">{task.title}</span>
          <span className="tp-task-time">{pad2(task.hour)}:{pad2(task.minute)} น.</span>
        </div>
      </div>
    </div>
  );
}
