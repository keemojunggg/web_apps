export const REPEAT_OPTIONS = [
  { id: 'none', label: 'ไม่ทำซ้ำ', desc: 'เพิ่มรายการครั้งเดียวในวันที่เลือก' },
  { id: 'daily', label: 'ทุกวัน', desc: 'เหมาะกับงานประจำวัน' },
  { id: 'monthly', label: 'ทุกเดือน', desc: 'เหมาะกับงานที่เกิดซ้ำรายเดือน' },
];
