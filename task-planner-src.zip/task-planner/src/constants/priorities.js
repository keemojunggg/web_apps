export const PRIORITIES = [
  { id: 'urgent', label: 'ด่วนที่สุด', color: 'var(--p-urgent)' },
  { id: 'scheduled', label: 'ตามเวลา', color: 'var(--p-scheduled)' },
  { id: 'relaxed', label: 'ไม่รีบ', color: 'var(--p-relaxed)' },
  { id: 'slow', label: 'ค่อยทำ', color: 'var(--p-slow)' },
];

export const PRIORITY_ORDER = { urgent: 0, scheduled: 1, relaxed: 2, slow: 3 };
