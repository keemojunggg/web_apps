import { Sun, Moon, User } from 'lucide-react';
import HeaderBar from '../components/HeaderBar';
import ToggleSwitch from '../components/ToggleSwitch';

export default function SettingsPage({
  theme, setTheme,
  notifyDefault, setNotifyDefault,
  leadMinutes, setLeadMinutes,
  profileName, setProfileName,
}) {
  return (
    <section className="tp-page">
      <HeaderBar theme={theme} setTheme={setTheme}><h2 className="tp-page-title">ตั้งค่า</h2></HeaderBar>

      <div className="tp-card tp-settings-card">
        <h3 className="tp-settings-heading">โปรไฟล์</h3>
        <div className="tp-profile-row">
          <span className="tp-avatar tp-avatar-lg">{profileName ? profileName[0] : <User size={20} />}</span>
          <input className="tp-text-input" value={profileName} onChange={(e) => setProfileName(e.target.value)} placeholder="ชื่อผู้ใช้" />
        </div>
      </div>

      <div className="tp-card tp-settings-card">
        <h3 className="tp-settings-heading">การแจ้งเตือน</h3>
        <ToggleSwitch checked={notifyDefault} onChange={setNotifyDefault} label="แจ้งเตือนก่อนถึงเวลา" description="ค่าเริ่มต้นสำหรับงานที่สร้างใหม่" />
        {notifyDefault && (
          <div className="tp-lead-row">
            <span>แจ้งล่วงหน้า</span>
            <select className="tp-select" value={leadMinutes} onChange={(e) => setLeadMinutes(Number(e.target.value))}>
              <option value={5}>5 นาที</option>
              <option value={10}>10 นาที</option>
              <option value={15}>15 นาที</option>
              <option value={30}>30 นาที</option>
              <option value={60}>1 ชั่วโมง</option>
            </select>
          </div>
        )}
      </div>

      <div className="tp-card tp-settings-card">
        <h3 className="tp-settings-heading">ธีม</h3>
        <div className="tp-theme-row">
          <button type="button" className={`tp-theme-option ${theme === 'light' ? 'is-active' : ''}`} onClick={() => setTheme('light')}>
            <Sun size={17} /> สว่าง
          </button>
          <button type="button" className={`tp-theme-option ${theme === 'dark' ? 'is-active' : ''}`} onClick={() => setTheme('dark')}>
            <Moon size={17} /> มืด
          </button>
        </div>
      </div>
    </section>
  );
}
