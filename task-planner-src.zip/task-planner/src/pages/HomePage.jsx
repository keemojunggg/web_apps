import { useState, useRef } from 'react';
import { Plus, Paperclip, ChevronLeft, ChevronRight, Calendar as CalendarIcon, X } from 'lucide-react';
import HeaderBar from '../components/HeaderBar';
import TimeReel from '../components/TimeReel';
import PriorityPicker from '../components/PriorityPicker';
import RepeatPicker from '../components/RepeatPicker';
import ToggleSwitch from '../components/ToggleSwitch';
import TaskItem from '../components/TaskItem';
import { addDays, toKey } from '../utils/dateUtils';

export default function HomePage({
  theme, setTheme,
  selectedDate, setSelectedDate,
  tasks, priorityMap,
  onAddTask, onToggle, onEdit, onDelete,
  notifyDefault, leadMinutes,
}) {
  const [title, setTitle] = useState('');
  const [hour, setHour] = useState(9);
  const [minute, setMinute] = useState(0);
  const [priority, setPriority] = useState('scheduled');
  const [repeat, setRepeat] = useState('none');
  const [notify, setNotify] = useState(notifyDefault);
  const [files, setFiles] = useState([]);
  const fileInputRef = useRef(null);

  const dateKey = toKey(selectedDate);
  const dayTasks = tasks
    .filter((t) => t.dateKey === dateKey)
    .sort((a, b) => a.hour * 60 + a.minute - (b.hour * 60 + b.minute));
  const doneCount = dayTasks.filter((t) => t.done).length;
  const progress = dayTasks.length ? Math.round((doneCount / dayTasks.length) * 100) : 0;

  const addFiles = (list) =>
    setFiles((prev) => [
      ...prev,
      ...Array.from(list).map((f) => ({ id: `${f.name}-${f.size}-${Math.random().toString(36).slice(2)}`, name: f.name })),
    ]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    onAddTask({ title: title.trim(), dateKey, hour, minute, priority, repeat, notify });
    setTitle('');
    setFiles([]);
  };

  return (
    <section className="tp-page">
      <HeaderBar theme={theme} setTheme={setTheme}>
        <button type="button" className="tp-icon-btn" onClick={() => setSelectedDate((d) => addDays(d, -1))} aria-label="วันก่อนหน้า">
          <ChevronLeft size={17} />
        </button>
        <h2 className="tp-page-title tp-date-title">
          <CalendarIcon size={18} className="tp-date-icon" />
          {selectedDate.getDate()} / {selectedDate.getMonth() + 1} / {selectedDate.getFullYear()}
        </h2>
        <button type="button" className="tp-icon-btn" onClick={() => setSelectedDate((d) => addDays(d, 1))} aria-label="วันถัดไป">
          <ChevronRight size={17} />
        </button>
      </HeaderBar>

      <div className="tp-home-grid">
        <form className="tp-card tp-form-card" onSubmit={handleSubmit}>
          <span className="tp-field-label">เวลา</span>
          <div className="tp-reel-row">
            <TimeReel value={hour} max={23} onChange={setHour} />
            <span className="tp-reel-colon">:</span>
            <TimeReel value={minute} max={59} onChange={setMinute} />
          </div>

          <input className="tp-text-input tp-title-input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="เพิ่มงานใหม่" />

          <div
            className="tp-dropzone"
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files); }}
          >
            <Paperclip size={17} />
            <span>ลากไฟล์มาวาง หรือคลิกเพื่อแนบไฟล์</span>
            <input ref={fileInputRef} type="file" multiple hidden onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
          </div>
          {files.length > 0 && (
            <ul className="tp-file-list">
              {files.map((f) => (
                <li key={f.id} className="tp-file-chip">
                  <span>{f.name}</span>
                  <button type="button" onClick={() => setFiles((prev) => prev.filter((x) => x.id !== f.id))} aria-label="นำไฟล์ออก">
                    <X size={12} />
                  </button>
                </li>
              ))}
            </ul>
          )}

          <button type="submit" className="tp-btn tp-btn-primary tp-btn-block">
            <Plus size={16} /> เพิ่มงาน
          </button>
        </form>

        <div className="tp-side-panels">
          <div className="tp-card tp-panel">
            <h3 className="tp-panel-title">ระดับความสำคัญ</h3>
            <PriorityPicker value={priority} onChange={setPriority} />
          </div>
          <div className="tp-card tp-panel">
            <h3 className="tp-panel-title">การทำซ้ำ</h3>
            <RepeatPicker value={repeat} onChange={setRepeat} />
          </div>
          <div className="tp-card tp-panel">
            <h3 className="tp-panel-title">การแจ้งเตือน</h3>
            <ToggleSwitch
              checked={notify}
              onChange={setNotify}
              label="แจ้งเตือนก่อนถึงเวลา"
              description={notify ? `แจ้งล่วงหน้า ${leadMinutes} นาที` : 'ปิดอยู่'}
            />
          </div>
        </div>
      </div>

      <div className="tp-card tp-tasklist-card">
        <div className="tp-tasklist-head">
          <h3>งานของวันนี้</h3>
          <span className="tp-tasklist-count">{doneCount}/{dayTasks.length} เสร็จแล้ว</span>
        </div>
        <div className="tp-gauge"><div className="tp-gauge-fill" style={{ width: `${progress}%` }} /></div>
        {dayTasks.length === 0 ? (
          <p className="tp-empty">ยังไม่มีงานในวันนี้ เพิ่มงานแรกของคุณด้านบนได้เลย</p>
        ) : (
          <ul className="tp-tasklist">
            {dayTasks.map((t) => (
              <li key={t.id}>
                <TaskItem task={t} priority={priorityMap[t.priority]} onToggle={onToggle} onEdit={onEdit} onDelete={onDelete} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
