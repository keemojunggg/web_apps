import { useState, useMemo } from 'react';
import HeaderBar from '../components/HeaderBar';
import TaskItem from '../components/TaskItem';
import { toKey, startOfDay, pad2, formatShortDate } from '../utils/dateUtils';
import { PRIORITIES, PRIORITY_ORDER } from '../constants/priorities';

const keyOf = (t) => `${t.dateKey} ${pad2(t.hour)}:${pad2(t.minute)}`;

export default function UpcomingPage({ theme, setTheme, tasks, priorityMap, onToggle, onEdit, onDelete }) {
  const [sortMode, setSortMode] = useState('priority'); // 'priority' | 'datetime'
  const todayKey = toKey(startOfDay(new Date()));
  const upcoming = tasks.filter((t) => !t.done && t.dateKey >= todayKey);

  const byDateTime = useMemo(
    () =>
      upcoming.slice().sort((a, b) => {
        const ka = keyOf(a);
        const kb = keyOf(b);
        if (ka !== kb) return ka < kb ? -1 : 1;
        return PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [tasks]
  );

  const byPriority = useMemo(
    () =>
      PRIORITIES.map((p) => ({
        priority: p,
        items: upcoming.filter((t) => t.priority === p.id).sort((a, b) => (keyOf(a) < keyOf(b) ? -1 : keyOf(a) > keyOf(b) ? 1 : 0)),
      })).filter((g) => g.items.length > 0),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [tasks]
  );

  return (
    <section className="tp-page">
      <HeaderBar theme={theme} setTheme={setTheme}><h2 className="tp-page-title">กำลังจะมาถึง</h2></HeaderBar>

      <div className="tp-segmented">
        <button type="button" className={sortMode === 'priority' ? 'is-active' : ''} onClick={() => setSortMode('priority')}>ตามความสำคัญ</button>
        <button type="button" className={sortMode === 'datetime' ? 'is-active' : ''} onClick={() => setSortMode('datetime')}>ตามวันเวลา</button>
      </div>

      {upcoming.length === 0 && <p className="tp-empty">ไม่มีงานที่กำลังจะมาถึง</p>}

      {sortMode === 'datetime' ? (
        <ul className="tp-tasklist">
          {byDateTime.map((t) => (
            <li key={t.id}>
              <div className="tp-upcoming-date">{formatShortDate(t.dateKey)}</div>
              <TaskItem task={t} priority={priorityMap[t.priority]} onToggle={onToggle} onEdit={onEdit} onDelete={onDelete} />
            </li>
          ))}
        </ul>
      ) : (
        byPriority.map((g) => (
          <div key={g.priority.id} className="tp-priority-group">
            <div className="tp-priority-group-head">
              <span className="tp-cal-dot" style={{ background: g.priority.color }} />
              <span>{g.priority.label}</span>
              <span className="tp-priority-count">{g.items.length}</span>
            </div>
            <ul className="tp-tasklist">
              {g.items.map((t) => (
                <li key={t.id}>
                  <div className="tp-upcoming-date">{formatShortDate(t.dateKey)}</div>
                  <TaskItem task={t} priority={priorityMap[t.priority]} onToggle={onToggle} onEdit={onEdit} onDelete={onDelete} />
                </li>
              ))}
            </ul>
          </div>
        ))
      )}
    </section>
  );
}
