import { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import HeaderBar from '../components/HeaderBar';
import TaskItem from '../components/TaskItem';
import { getMonthMatrix, toKey, startOfDay } from '../utils/dateUtils';
import { MONTHS_TH, WEEKDAYS_TH } from '../constants/calendar';

export default function CalendarPage({
  theme, setTheme,
  tasks, priorityMap,
  selectedDate, setSelectedDate, setPage,
  onToggle, onEdit, onDelete,
}) {
  const [viewDate, setViewDate] = useState(() => new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1));
  const weeks = useMemo(() => getMonthMatrix(viewDate.getFullYear(), viewDate.getMonth()), [viewDate]);
  const todayKey = toKey(startOfDay(new Date()));
  const selectedKey = toKey(selectedDate);

  const tasksByDate = useMemo(() => {
    const map = {};
    tasks.forEach((t) => { (map[t.dateKey] ||= []).push(t); });
    return map;
  }, [tasks]);

  const dayTasks = (tasksByDate[selectedKey] || [])
    .slice()
    .sort((a, b) => a.hour * 60 + a.minute - (b.hour * 60 + b.minute));

  return (
    <section className="tp-page">
      <HeaderBar theme={theme} setTheme={setTheme}><h2 className="tp-page-title">ปฏิทิน</h2></HeaderBar>

      <div className="tp-card">
        <div className="tp-cal-nav">
          <button type="button" className="tp-icon-btn" onClick={() => setViewDate((d) => new Date(d.getFullYear(), d.getMonth() - 1, 1))} aria-label="เดือนก่อนหน้า">
            <ChevronLeft size={17} />
          </button>
          <span className="tp-cal-month">{MONTHS_TH[viewDate.getMonth()]} {viewDate.getFullYear()}</span>
          <button type="button" className="tp-icon-btn" onClick={() => setViewDate((d) => new Date(d.getFullYear(), d.getMonth() + 1, 1))} aria-label="เดือนถัดไป">
            <ChevronRight size={17} />
          </button>
        </div>

        <div className="tp-cal-grid">
          {WEEKDAYS_TH.map((w) => <div key={w} className="tp-cal-weekday">{w}</div>)}
          {weeks.flat().map((date, i) => {
            const key = toKey(date);
            const inMonth = date.getMonth() === viewDate.getMonth();
            const dayList = tasksByDate[key] || [];
            return (
              <button
                key={i}
                type="button"
                className={`tp-cal-cell ${inMonth ? '' : 'is-outside'} ${key === todayKey ? 'is-today' : ''} ${key === selectedKey ? 'is-selected' : ''}`}
                onClick={() => setSelectedDate(date)}
              >
                <span className="tp-cal-date">{date.getDate()}</span>
                {dayList.length > 0 && (
                  <span className="tp-cal-dots">
                    {dayList.slice(0, 3).map((t) => (
                      <span key={t.id} className="tp-cal-dot" style={{ background: priorityMap[t.priority].color }} />
                    ))}
                    {dayList.length > 3 && <span className="tp-cal-more">+{dayList.length - 3}</span>}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="tp-card tp-cal-daypanel">
        <div className="tp-cal-daypanel-head">
          <h3>{selectedDate.getDate()} {MONTHS_TH[selectedDate.getMonth()]} {selectedDate.getFullYear()}</h3>
          <button type="button" className="tp-btn tp-btn-ghost tp-btn-sm" onClick={() => setPage('home')}>
            <Plus size={14} /> เพิ่มงานวันนี้
          </button>
        </div>
        {dayTasks.length === 0 ? (
          <p className="tp-empty">ไม่มีงานในวันนี้</p>
        ) : (
          <ul className="tp-tasklist">
            {dayTasks.map((t) => (
              <li key={t.id}>
                <TaskItem task={t} priority={priorityMap[t.priority]} onToggle={onToggle} onEdit={onEdit} onDelete={onDelete} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
